#!/usr/bin/env bash
set -euo pipefail

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 18+ is required. Install it from https://nodejs.org/"
  exit 1
fi

if command -v pnpm >/dev/null 2>&1; then
  pnpm install
elif command -v npm >/dev/null 2>&1; then
  npm install
else
  echo "pnpm or npm is required."
  exit 1
fi

echo "CampusSubmit setup complete. Run ./start.sh to launch the app."
