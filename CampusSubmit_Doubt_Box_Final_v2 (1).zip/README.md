# CampusSubmit Prototype

## New feature: Student–Teacher Doubt Box
- Students open **Anonymous doubt box**, enter a question, and select **Send doubt**.
- Teachers switch to **Faculty view**, open **Anonymous doubt box**, and can answer submitted questions.
- Students can switch back to **Student view** to see replies and the status of each doubt.
- Doubts and answers are shared between the student and teacher views while the app is running in the same browser session. This demo stores them in client-side state; restarting/reloading the app clears them.

## Run on Windows
1. Install a supported Node.js LTS release.
2. Extract this ZIP.
3. Open the extracted folder in Terminal/Command Prompt.
4. Run `npm install` (or `pnpm install` if using pnpm).
5. Run `npm run dev` (or `pnpm dev`).
6. Open the local URL printed in the terminal, usually `http://localhost:3000`.

## Demo teacher access
Use the existing demo teacher login flow and credentials already configured in the prototype.
